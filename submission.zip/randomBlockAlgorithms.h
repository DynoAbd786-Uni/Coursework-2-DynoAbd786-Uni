int ebcCompressToRandomBlock(int argc, char **argv);

int ebcDecompressFromRandomBlock(int argc, char **argv);