#include "randomBlockAlgorithms.h"

int main(int argc, char **argv)
{
    // run program
    return ebcDecompressFromRandomBlock(argc, argv);
}