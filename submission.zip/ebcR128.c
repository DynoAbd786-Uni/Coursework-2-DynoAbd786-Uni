#include "randomBlockAlgorithms.h"

int main(int argc, char **argv)
{
    // run program
    return ebcCompressToRandomBlock(argc, argv);
}